# Ninja Academy — your project

One HTML file, no build step, nothing to install.

## To work on it

1. Unzip this folder anywhere on your computer.
2. Double-click `index.html` to play it. That is the whole game.
3. To change it, open `index.html` in a code editor. VS Code is free.
4. Save the file, then refresh the browser tab to see your change.

Everything is in that one file: the HTML, the styling and the code.
Find the bit you want to change and edit it in place.

## The first-person prototype

The `prototype/` folder is the 3D first-person version. Open
`prototype/index.html` to run it. The original source for it is
`ninja-academy-fp.jsx` — that one is React + three.js, so it needs
bundling before it runs in a browser (ask Uncle B, or use esbuild).

## Tips

- Work on a copy first, so you always have a version that runs.
- Small changes, refresh, check. Not twenty changes at once.
- If it breaks, press F12 in the browser and read the red text in
  Console. It will tell you the line number.

## To put a new version online

Send the edited `index.html` to Uncle B and it goes back up at:
https://altitudeaico.github.io/goteamolatoyes/codequest/triad-labs/ninja-academy/

Built at Code Quest 2026.
