# Non-League — your project

A season in the sixth tier. One HTML file, no build step, nothing to install.

## To work on it

1. Unzip this folder anywhere on your computer.
2. Double-click `index.html` to play it. That is the whole game.
3. To change it, open `index.html` in a code editor. VS Code is free.
4. Save the file, then refresh the browser tab to see your change.

Everything is in that one file: the HTML, the styling and the code.
Find the bit you want to change and edit it in place.

## Tips

- Work on a copy first, so you always have a version that runs.
- Small changes, refresh, check. Not twenty changes at once.
- If it breaks, press F12 in the browser and read the red text in Console.
  It will tell you the line number.

## To put a new version online

Send the edited `index.html` to Uncle B and it goes back up at:
https://altitudeaico.github.io/goteamolatoyes/codequest/triad-labs/non-league/

## One thing to know

The game loads its fonts from Google, so with no internet it still works
but looks slightly different.

Built at Code Quest 2026. Presented 15:25, Saturday 1 August.
