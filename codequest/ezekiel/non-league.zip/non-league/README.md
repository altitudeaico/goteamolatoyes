# Non-League

A season in the sixth tier. Browser football management, built for Code Quest 2026.

By Ezekiel · Triad Labs

## Running it

Double-click `index.html`. That's it. No install, no server, no build step.
It works offline.

## Editing it

Open `index.html` in any code editor. Everything is in that one file:
the HTML, the CSS and the JavaScript.

Useful things to know:

- **Find the bit you want** — search the file for text you can see on screen.
  If you want to change the squad screen, search for a word that appears on it.
- **Save, then refresh the browser.** Changes appear instantly.
- **Keep a copy before big changes.** Duplicate the file and call it
  `index-backup.html` so you can always go back.

## Ideas for version two

- More than one season, so results carry forward
- Player injuries and suspensions
- A transfer window with a budget
- Saving your progress so it survives closing the tab
- A cup competition alongside the league

## Files

| File | What it is |
|---|---|
| `index.html` | The game. Everything is in here. |
| `non-league-breakdown.pdf` | The presentation, as slides |
| `non-league-breakdown.pptx` | The presentation, editable |

Live at:
https://altitudeaico.github.io/goteamolatoyes/codequest/triad-labs/non-league/
