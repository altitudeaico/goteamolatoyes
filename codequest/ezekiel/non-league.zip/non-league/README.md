# Non-League

**A season in the sixth tier.** By Ezekiel, Triad Labs, Code Quest 2026.

Twenty-two Saturdays. One squad. One bank account. An owner who wants
something specific from you, and a dressing room that will not always agree.

---

## Running it

Double-click `index.html`. That is it.

No install, no build step, no server, no internet needed. It is one HTML
file with everything inside it: the code, the styling and the data.

## Working on it

Open `index.html` in any code editor. VS Code is free and good.

Everything lives in that one file:

- **The look** is inside the `<style>` block near the top
- **The game** is inside the `<script>` block near the bottom
- Search for a word you can see on screen to find the part that draws it

Change something, save, then refresh the page in the browser. That is the
whole loop.

## A warning worth taking

**Keep a copy before you change anything big.** Duplicate the file and call
it `index-backup.html`. When something breaks badly and you cannot work out
why, you have somewhere to go back to.

## If it stops working

Open the browser console to see the error:

- **Chrome / Edge** — press F12, click Console
- **Safari** — turn on the Develop menu in Settings, then Develop, Show JavaScript Console

A red message with a line number tells you where to look. Nine times out of
ten it is a missing bracket or comma near the last thing you edited.

## The deck

`non-league-breakdown.pptx` is the presentation, and `non-league-breakdown.pdf`
is the same thing as a PDF, which opens anywhere without PowerPoint.

---

Live at: altitudeaico.github.io/goteamolatoyes/codequest/triad-labs/non-league/
